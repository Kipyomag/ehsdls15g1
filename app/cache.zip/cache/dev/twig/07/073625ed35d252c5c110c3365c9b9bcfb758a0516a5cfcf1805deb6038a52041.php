<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_7d5bf45a987f26bb53a00fd7451b4fe988a4082d0b955173b198285676501322 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2948f6167bf2e485980b53033882d0d47e30efb822be39b3ff9db47b5e321f3e = $this->env->getExtension("native_profiler");
        $__internal_2948f6167bf2e485980b53033882d0d47e30efb822be39b3ff9db47b5e321f3e->enter($__internal_2948f6167bf2e485980b53033882d0d47e30efb822be39b3ff9db47b5e321f3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_2948f6167bf2e485980b53033882d0d47e30efb822be39b3ff9db47b5e321f3e->leave($__internal_2948f6167bf2e485980b53033882d0d47e30efb822be39b3ff9db47b5e321f3e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
