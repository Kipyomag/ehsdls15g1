<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_3852a8aa373a9246a5d5d9a37a85bc865e97d48cce474767cadf4fc564ca4e32 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c9ac139f39b4264ad338818ec915b96f64249c23509afa7227dd854863864e1e = $this->env->getExtension("native_profiler");
        $__internal_c9ac139f39b4264ad338818ec915b96f64249c23509afa7227dd854863864e1e->enter($__internal_c9ac139f39b4264ad338818ec915b96f64249c23509afa7227dd854863864e1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_c9ac139f39b4264ad338818ec915b96f64249c23509afa7227dd854863864e1e->leave($__internal_c9ac139f39b4264ad338818ec915b96f64249c23509afa7227dd854863864e1e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */
