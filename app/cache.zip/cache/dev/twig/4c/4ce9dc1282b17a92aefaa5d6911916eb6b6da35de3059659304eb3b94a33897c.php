<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_9162988e7f3c16830dd792dd16c0e23c5e2a702313de8a0018c185ce4c3462c4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_042a4e130a732ba5e0e6ba40d66857d645e33d61bb4642db07c7e55a84a58a99 = $this->env->getExtension("native_profiler");
        $__internal_042a4e130a732ba5e0e6ba40d66857d645e33d61bb4642db07c7e55a84a58a99->enter($__internal_042a4e130a732ba5e0e6ba40d66857d645e33d61bb4642db07c7e55a84a58a99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_042a4e130a732ba5e0e6ba40d66857d645e33d61bb4642db07c7e55a84a58a99->leave($__internal_042a4e130a732ba5e0e6ba40d66857d645e33d61bb4642db07c7e55a84a58a99_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */
