<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_97b759b91a6859282d94295ae0069104f2437506e6f00d4c8ede849eb227138a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e40b4405ab3acc2955a14cd82fc724043b8ac5eb7f3ab0559bfa9eda1c013ef7 = $this->env->getExtension("native_profiler");
        $__internal_e40b4405ab3acc2955a14cd82fc724043b8ac5eb7f3ab0559bfa9eda1c013ef7->enter($__internal_e40b4405ab3acc2955a14cd82fc724043b8ac5eb7f3ab0559bfa9eda1c013ef7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_e40b4405ab3acc2955a14cd82fc724043b8ac5eb7f3ab0559bfa9eda1c013ef7->leave($__internal_e40b4405ab3acc2955a14cd82fc724043b8ac5eb7f3ab0559bfa9eda1c013ef7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
