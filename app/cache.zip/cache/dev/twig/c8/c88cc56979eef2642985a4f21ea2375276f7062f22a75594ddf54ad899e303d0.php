<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_edcdb995082e667e872b57edb8d12a737741a163b0751fd0419560f168a4d9a3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_42cf8cae1b39de7206c8b900d8d0e1744e2690d2c9d2fbb72b358c1cc8d4d3a1 = $this->env->getExtension("native_profiler");
        $__internal_42cf8cae1b39de7206c8b900d8d0e1744e2690d2c9d2fbb72b358c1cc8d4d3a1->enter($__internal_42cf8cae1b39de7206c8b900d8d0e1744e2690d2c9d2fbb72b358c1cc8d4d3a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_42cf8cae1b39de7206c8b900d8d0e1744e2690d2c9d2fbb72b358c1cc8d4d3a1->leave($__internal_42cf8cae1b39de7206c8b900d8d0e1744e2690d2c9d2fbb72b358c1cc8d4d3a1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
