<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_f0201d0bb0261f9bbae95dca3bc73d70d0e73e417bd19d0a09337cce28b86549 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_30ebfed04a1e472df039ad50e26546047673f7003c0b68de8b7be976e3704fd6 = $this->env->getExtension("native_profiler");
        $__internal_30ebfed04a1e472df039ad50e26546047673f7003c0b68de8b7be976e3704fd6->enter($__internal_30ebfed04a1e472df039ad50e26546047673f7003c0b68de8b7be976e3704fd6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_30ebfed04a1e472df039ad50e26546047673f7003c0b68de8b7be976e3704fd6->leave($__internal_30ebfed04a1e472df039ad50e26546047673f7003c0b68de8b7be976e3704fd6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->start($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* <?php echo $view['form']->end($form) ?>*/
/* */
