<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_abb0be308f518c692641d1f272f655895b708e1021edb73db608fb7003240e00 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a3ab15e2ffa27444db34d293782307a3e9a6ed3d0f3639f62b9611989792f1c6 = $this->env->getExtension("native_profiler");
        $__internal_a3ab15e2ffa27444db34d293782307a3e9a6ed3d0f3639f62b9611989792f1c6->enter($__internal_a3ab15e2ffa27444db34d293782307a3e9a6ed3d0f3639f62b9611989792f1c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.rdf.twig", 1)->display($context);
        
        $__internal_a3ab15e2ffa27444db34d293782307a3e9a6ed3d0f3639f62b9611989792f1c6->leave($__internal_a3ab15e2ffa27444db34d293782307a3e9a6ed3d0f3639f62b9611989792f1c6_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
