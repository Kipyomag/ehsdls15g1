<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_84763b6f74edd2f14dc65c64583b8e30ba4184076e4ade04f861191515eee634 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9cd7c819e4af4edbacafa3afee1de7fc8e1745530f1d383509c6bd08a8b97396 = $this->env->getExtension("native_profiler");
        $__internal_9cd7c819e4af4edbacafa3afee1de7fc8e1745530f1d383509c6bd08a8b97396->enter($__internal_9cd7c819e4af4edbacafa3afee1de7fc8e1745530f1d383509c6bd08a8b97396_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_9cd7c819e4af4edbacafa3afee1de7fc8e1745530f1d383509c6bd08a8b97396->leave($__internal_9cd7c819e4af4edbacafa3afee1de7fc8e1745530f1d383509c6bd08a8b97396_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */
