<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_2f31746be6f5a729278c32bed35e715ef0fef6fb08fae8d75321fb8689e13269 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cd70093294bcf3d358cc0c1687b26d5bf0224ea2270be46c1130505c7e7d13e0 = $this->env->getExtension("native_profiler");
        $__internal_cd70093294bcf3d358cc0c1687b26d5bf0224ea2270be46c1130505c7e7d13e0->enter($__internal_cd70093294bcf3d358cc0c1687b26d5bf0224ea2270be46c1130505c7e7d13e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_cd70093294bcf3d358cc0c1687b26d5bf0224ea2270be46c1130505c7e7d13e0->leave($__internal_cd70093294bcf3d358cc0c1687b26d5bf0224ea2270be46c1130505c7e7d13e0_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_7ca516c36c706d1e5438ebbb946b81358086a32741a200ec5ab26adf60e0134e = $this->env->getExtension("native_profiler");
        $__internal_7ca516c36c706d1e5438ebbb946b81358086a32741a200ec5ab26adf60e0134e->enter($__internal_7ca516c36c706d1e5438ebbb946b81358086a32741a200ec5ab26adf60e0134e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_7ca516c36c706d1e5438ebbb946b81358086a32741a200ec5ab26adf60e0134e->leave($__internal_7ca516c36c706d1e5438ebbb946b81358086a32741a200ec5ab26adf60e0134e_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
