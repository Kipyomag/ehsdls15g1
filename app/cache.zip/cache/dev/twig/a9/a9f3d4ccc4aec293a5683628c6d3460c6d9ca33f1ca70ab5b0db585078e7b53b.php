<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_47b01b9f5d99fb4315bb12eb100d0325708d2081bc77a2c5ad2cf7776f1e7c60 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8adf0990650c1de776c53a23bd9e1fe951e665fffa61fba60f7d82cc4945f9db = $this->env->getExtension("native_profiler");
        $__internal_8adf0990650c1de776c53a23bd9e1fe951e665fffa61fba60f7d82cc4945f9db->enter($__internal_8adf0990650c1de776c53a23bd9e1fe951e665fffa61fba60f7d82cc4945f9db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_8adf0990650c1de776c53a23bd9e1fe951e665fffa61fba60f7d82cc4945f9db->leave($__internal_8adf0990650c1de776c53a23bd9e1fe951e665fffa61fba60f7d82cc4945f9db_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/* */
