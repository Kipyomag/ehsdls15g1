<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_29242cd8390ff040e9556c5e9fec44cd0dc969de2ebaa1d4e8b9b731514eba8d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e8a6f598169fb35b1631c44620f8941b38a6ad7a9d1d8f2047ef5953f54c4c4c = $this->env->getExtension("native_profiler");
        $__internal_e8a6f598169fb35b1631c44620f8941b38a6ad7a9d1d8f2047ef5953f54c4c4c->enter($__internal_e8a6f598169fb35b1631c44620f8941b38a6ad7a9d1d8f2047ef5953f54c4c4c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_e8a6f598169fb35b1631c44620f8941b38a6ad7a9d1d8f2047ef5953f54c4c4c->leave($__internal_e8a6f598169fb35b1631c44620f8941b38a6ad7a9d1d8f2047ef5953f54c4c4c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
