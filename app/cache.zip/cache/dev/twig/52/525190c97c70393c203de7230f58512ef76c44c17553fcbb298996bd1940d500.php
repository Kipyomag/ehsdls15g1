<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_cce3e21434d0523757a8968466d99fbc5a8108c74ffca29ae6f2cb00cd562022 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_060d42bce35d89ac4911d2f38dd4fdef46e6a1868038af79f88a83f50f1bb22c = $this->env->getExtension("native_profiler");
        $__internal_060d42bce35d89ac4911d2f38dd4fdef46e6a1868038af79f88a83f50f1bb22c->enter($__internal_060d42bce35d89ac4911d2f38dd4fdef46e6a1868038af79f88a83f50f1bb22c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_060d42bce35d89ac4911d2f38dd4fdef46e6a1868038af79f88a83f50f1bb22c->leave($__internal_060d42bce35d89ac4911d2f38dd4fdef46e6a1868038af79f88a83f50f1bb22c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
