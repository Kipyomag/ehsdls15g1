<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_f089bc649523c7a62fb056fddfeb9bf6120d2fa2399924e8b12c83fc6c14e0fb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e786bf2593d8057196b8be6d5d42895409e447c0da86f71cfea451d5cb452463 = $this->env->getExtension("native_profiler");
        $__internal_e786bf2593d8057196b8be6d5d42895409e447c0da86f71cfea451d5cb452463->enter($__internal_e786bf2593d8057196b8be6d5d42895409e447c0da86f71cfea451d5cb452463_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_e786bf2593d8057196b8be6d5d42895409e447c0da86f71cfea451d5cb452463->leave($__internal_e786bf2593d8057196b8be6d5d42895409e447c0da86f71cfea451d5cb452463_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
