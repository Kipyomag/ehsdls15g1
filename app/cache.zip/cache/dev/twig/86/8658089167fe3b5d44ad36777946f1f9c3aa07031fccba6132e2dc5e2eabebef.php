<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_a7b3b80c86d886b218957d99e4693efbd6fa448d875e3f7e601b4e96ab8bc3f5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6e65fbf56c6b69ba37c1780d4a011e3b7ff3155c10e663c8802a5d3dc2ff8d75 = $this->env->getExtension("native_profiler");
        $__internal_6e65fbf56c6b69ba37c1780d4a011e3b7ff3155c10e663c8802a5d3dc2ff8d75->enter($__internal_6e65fbf56c6b69ba37c1780d4a011e3b7ff3155c10e663c8802a5d3dc2ff8d75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_6e65fbf56c6b69ba37c1780d4a011e3b7ff3155c10e663c8802a5d3dc2ff8d75->leave($__internal_6e65fbf56c6b69ba37c1780d4a011e3b7ff3155c10e663c8802a5d3dc2ff8d75_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */
