<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_2334ac9bafb0d8b521fd4518767e9b617e0ee553fc4186a27db636a178c61d71 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b678906497e3403e44097a84ab0c444ebaa04ed33362c9e86b7eea51cf7ef37d = $this->env->getExtension("native_profiler");
        $__internal_b678906497e3403e44097a84ab0c444ebaa04ed33362c9e86b7eea51cf7ef37d->enter($__internal_b678906497e3403e44097a84ab0c444ebaa04ed33362c9e86b7eea51cf7ef37d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_b678906497e3403e44097a84ab0c444ebaa04ed33362c9e86b7eea51cf7ef37d->leave($__internal_b678906497e3403e44097a84ab0c444ebaa04ed33362c9e86b7eea51cf7ef37d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'url')) ?>*/
/* */
