<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_373de0609ea4301817303c43bbafe9188273dffdeffa448841a0a452ee590100 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8d6cd26782f09102c409dfa115d415a6388f190569bfb1a5d17fee2c462936f7 = $this->env->getExtension("native_profiler");
        $__internal_8d6cd26782f09102c409dfa115d415a6388f190569bfb1a5d17fee2c462936f7->enter($__internal_8d6cd26782f09102c409dfa115d415a6388f190569bfb1a5d17fee2c462936f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_8d6cd26782f09102c409dfa115d415a6388f190569bfb1a5d17fee2c462936f7->leave($__internal_8d6cd26782f09102c409dfa115d415a6388f190569bfb1a5d17fee2c462936f7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'submit')) ?>*/
/* */
