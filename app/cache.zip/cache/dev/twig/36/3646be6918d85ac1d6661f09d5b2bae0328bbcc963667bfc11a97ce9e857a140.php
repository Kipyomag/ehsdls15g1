<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_13841c9284a8c35f0fbaa6d3ee84f22c7938c971f642d3d5beab3c76b9ba53cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ab432d3e0fe6a2d840c24a6902614073381d71f5fb430095b875b585f9b9968c = $this->env->getExtension("native_profiler");
        $__internal_ab432d3e0fe6a2d840c24a6902614073381d71f5fb430095b875b585f9b9968c->enter($__internal_ab432d3e0fe6a2d840c24a6902614073381d71f5fb430095b875b585f9b9968c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_ab432d3e0fe6a2d840c24a6902614073381d71f5fb430095b875b585f9b9968c->leave($__internal_ab432d3e0fe6a2d840c24a6902614073381d71f5fb430095b875b585f9b9968c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'number')) ?>*/
/* */
