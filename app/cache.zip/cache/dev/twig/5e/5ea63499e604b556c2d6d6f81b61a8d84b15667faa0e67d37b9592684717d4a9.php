<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_5f793959bff10e94d33c841a3876b2fa59a64e486018ea0423ace36b068c0d54 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7b10ad78349c3e66cfd551bad89edb79f79c7f77976fb47e66fa1e674727c836 = $this->env->getExtension("native_profiler");
        $__internal_7b10ad78349c3e66cfd551bad89edb79f79c7f77976fb47e66fa1e674727c836->enter($__internal_7b10ad78349c3e66cfd551bad89edb79f79c7f77976fb47e66fa1e674727c836_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_7b10ad78349c3e66cfd551bad89edb79f79c7f77976fb47e66fa1e674727c836->leave($__internal_7b10ad78349c3e66cfd551bad89edb79f79c7f77976fb47e66fa1e674727c836_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>*/
/* */
