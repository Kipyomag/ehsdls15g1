<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_500cb31241f9b89ca70ff2d69da863e836569ca5f5a805d7b3a08997d709f6da extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4dd3fb3729f08075c6806453cb8ff126add85f6e93b1fa6dd1aacbc20f95e256 = $this->env->getExtension("native_profiler");
        $__internal_4dd3fb3729f08075c6806453cb8ff126add85f6e93b1fa6dd1aacbc20f95e256->enter($__internal_4dd3fb3729f08075c6806453cb8ff126add85f6e93b1fa6dd1aacbc20f95e256_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_4dd3fb3729f08075c6806453cb8ff126add85f6e93b1fa6dd1aacbc20f95e256->leave($__internal_4dd3fb3729f08075c6806453cb8ff126add85f6e93b1fa6dd1aacbc20f95e256_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_container_attributes') ?>*/
/* */
