<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_da56c122d961f3ffe73a19ae4f9446843b88b79a00938f2226bc1703de816495 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2a8b47b051331435680f43764f8c1190b3fb0f1b82a3f7efc359ddd2250d6d16 = $this->env->getExtension("native_profiler");
        $__internal_2a8b47b051331435680f43764f8c1190b3fb0f1b82a3f7efc359ddd2250d6d16->enter($__internal_2a8b47b051331435680f43764f8c1190b3fb0f1b82a3f7efc359ddd2250d6d16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_2a8b47b051331435680f43764f8c1190b3fb0f1b82a3f7efc359ddd2250d6d16->leave($__internal_2a8b47b051331435680f43764f8c1190b3fb0f1b82a3f7efc359ddd2250d6d16_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */
